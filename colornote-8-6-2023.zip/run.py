from source import socketIo,app
from source.socket import *

import source.main.controller



if __name__ == '__main__':
    socketIo.run(app,host="0.0.0.0",port=18011)
