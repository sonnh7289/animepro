

import Foundation

extension Int {
    public func toString() -> String {
        return "\(self)"
    }
}
